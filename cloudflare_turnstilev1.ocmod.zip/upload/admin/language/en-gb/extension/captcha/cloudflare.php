<?php
$_['heading_title']    = 'Cloudflare Turnstile';
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Cloudflare Turnstile!';
$_['text_edit']        = 'Edit Cloudflare Turnstile';
$_['entry_site_key']   = 'Site Key';
$_['entry_secret_key'] = 'Secret Key';
$_['entry_status']     = 'Status';
$_['error_permission'] = 'Warning: You do not have permission to modify Cloudflare Turnstile!'; 